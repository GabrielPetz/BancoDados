CREATE OR REPLACE PACKAGE UTIL AS

FUNCTION VALIDACPF(NRCPF NUMBER) RETURN NUMBER;
FUNCTION VALIDACNPJ(NRCNPJ NUMBER) RETURN NUMBER;

END UTIL;

CREATE OR REPLACE PACKAGE BODY UTIL AS 

FUNCTION VALIDACPF(NRCPF NUMBER) RETURN NUMBER IS
BEGIN
DECLARE 
	TYPE ARRAYCPF IS VARRAY(11) OF NUMBER(1);
	CPF ARRAYCPF := ARRAYCPF();
	CPFSTRING VARCHAR2(11);
	SOMA NUMBER(30);
	DIGITO1 NUMBER(5) := 0;
	DIGITO2 NUMBER(5) := 0;
BEGIN
		CPFSTRING := LPAD( TO_CHAR( NRCPF ), 11, '0'); 
		dbms_output.put_line('CPF recebido: ');
		dbms_output.put_line(CPFSTRING);
		dbms_output.put_line('-----------------------------------------------');
		FOR I IN 1..LENGTH(CPFSTRING) LOOP
			CPF.EXTEND();
			CPF(I) := SUBSTR(CPFSTRING, I, 1);
			dbms_output.put_line(CPF(I));
		END LOOP;
			dbms_output.put_line('-----------------------------------------------');
		FOR I IN 1..9 LOOP
			DIGITO1 := DIGITO1 + ( CPF(I) * ( 11 - I ) );
			dbms_output.put_line(DIGITO1);
		END LOOP;
			dbms_output.put_line('-----------------------------------------------');

		DIGITO1 := DIGITO1 * 10;

		DIGITO1 := MOD(DIGITO1, 11);

		IF DIGITO1 = 10 THEN 
		DIGITO1 := 0;
		END IF; 

		IF DIGITO1 != CPF(10)
		THEN RETURN 0;
		END IF; 
		
		dbms_output.put_line('Digito verificador 1 : ');
		dbms_output.put_line(DIGITO1);
		dbms_output.put_line('-----------------------------------------------');


		FOR I IN 1..10 LOOP
			DIGITO2 := DIGITO2 + ( CPF(I) * ( 12 - I ) );
			dbms_output.put_line(DIGITO2);
		END LOOP;
			dbms_output.put_line('-----------------------------------------------');

				DIGITO2 := DIGITO2 * 10;

				DIGITO2 := MOD(DIGITO2, 11);

				IF DIGITO2 = 10 THEN 
				DIGITO2 := 0;
				END IF; 

				IF DIGITO2 != CPF(11)
				THEN RETURN 0;
				END IF; 


			dbms_output.put_line('Digito verificador 2 : ');
			dbms_output.put_line(DIGITO2);
			dbms_output.put_line('-----------------------------------------------');



		RETURN 1;
END;
END;


FUNCTION VALIDACNPJ(NRCNPJ NUMBER) RETURN NUMBER IS
BEGIN
DECLARE 
	TYPE ARRAYCNPJ IS VARRAY(14) OF NUMBER(1);
	CNPJ ARRAYCNPJ := ARRAYCNPJ();
	MASK ARRAYCNPJ := ARRAYCNPJ();

	CNPJSTRING VARCHAR2(14);
	SOMA NUMBER(30);
	DIGITO1 NUMBER(10) := 0;
	DIGITO2 NUMBER(10) := 0;
BEGIN
		CNPJSTRING := LPAD( TO_CHAR( NRCNPJ ), 14, '0'); 
		dbms_output.put_line('CNPJ recebido: ');
		dbms_output.put_line(CNPJSTRING);
		dbms_output.put_line('-----------------------------------------------');


		MASK.EXTEND(14);
		MASK(1) := 6;
		MASK(2) := 5;
		MASK(3) := 4;
		MASK(4) := 3;
		MASK(5) := 2;
		MASK(6) := 9;
		MASK(7) := 8;
		MASK(8) := 7;
		MASK(9) := 6;
		MASK(10) := 5;
		MASK(11) := 4;
		MASK(12) := 3;
		MASK(13) := 2;

		FOR I IN 1..LENGTH(CNPJSTRING) LOOP
			CNPJ.EXTEND();
			CNPJ(I) := SUBSTR(CNPJSTRING, I, 1);
			dbms_output.put_line(CNPJ(I));
		END LOOP;
			dbms_output.put_line('-----------------------------------------------');
		
		FOR I IN 1..12 LOOP

			DIGITO1 := DIGITO1 + ( CNPJ(I) * MASK(I + 1) );
			dbms_output.put_line(DIGITO1);
		END LOOP;
			dbms_output.put_line('-----------------------------------------------');

		DIGITO1 := MOD(DIGITO1, 11);

		IF DIGITO1 < 2 THEN 
		DIGITO1 := 0;
		ELSE 
		DIGITO1 := 11 - DIGITO1;
		END IF; 

		IF DIGITO1 != CNPJ(13)
		THEN RETURN 0;
		END IF; 
		
		dbms_output.put_line('Digito verificador 1 : ');
		dbms_output.put_line(DIGITO1);
		dbms_output.put_line('-----------------------------------------------');


		FOR I IN 1..13 LOOP
			DIGITO2 := DIGITO2 + ( CNPJ(I) * MASK(I) );
			dbms_output.put_line(DIGITO2);
		END LOOP;
			dbms_output.put_line('-----------------------------------------------');

				DIGITO2 := MOD(DIGITO2, 11);

				IF DIGITO2 < 2 THEN 
				DIGITO2 := 0;
				ELSE 
				DIGITO2 := 11 - DIGITO2;
				END IF; 

				IF DIGITO2 != CNPJ(14)
				THEN RETURN 0;
				END IF; 


			dbms_output.put_line('Digito verificador 2 : ');
			dbms_output.put_line(DIGITO2);
			dbms_output.put_line('-----------------------------------------------');



		RETURN 1;
END;
END;
END UTIL;
/